import sys
import os
import logging
from logging.handlers import RotatingFileHandler

# import service
# from gui import main as call_gui
from specqp import service
from specqp.gui import main as call_gui


specqp_logger = logging.getLogger("specqp")


def initialize_logging():
    """Setting up the main logger for the app
    """
    specqp_logger.setLevel(logging.DEBUG)  # Main level filter for log messages (with DEBUG all messages are evaluated)

    # Setting up console output with more information to be logged
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)  # Secondary level filter for log messages in console

    # Create the log directory if doesn't exist
    directory = os.path.dirname(service.service_vars["LOG_FILE_NAME"])
    if not os.path.exists(directory):
        os.makedirs(directory)
    # Setting up logfile output with only errors and critical errors to be logged
    # Set rotating handlers so that the logfile doesn't grow forever
    file_handler = RotatingFileHandler(service.service_vars["LOG_FILE_NAME"], maxBytes=1000000, backupCount=3)
    file_handler.setLevel(logging.ERROR)  # Secondary level filter for log messages in file

    formatter = logging.Formatter("%(asctime)s (%(levelname)s in %(name)s): %(message)s", "%Y-%m-%d %H:%M:%S")
    console_handler.setFormatter(formatter)
    file_handler.setFormatter(formatter)

    specqp_logger.addHandler(console_handler)
    specqp_logger.addHandler(file_handler)


def parse_file(file_name, region_name=None):
    files_list = []
    parameters = {}
    section_start = False
    section_end = False
    enable_comments = True
    with open(file_name, 'r') as f:
        lines = f.readlines()
        parameters["COMMENT"] = ""
        for line in lines:
            if section_end:
                break
            if line[0] == '#':
                if line[1] == "#" and line[2] != '#' and enable_comments:
                    parameters["COMMENT"] += line.strip('# \n') + '\n'
                continue
            if line[0] == '[' and not region_name and len(files_list) == 0:
                section_start = True
                enable_comments = True
                continue
            if section_start:
                if line[0] == '[' and len(files_list) > 0:
                    section_end = True
                    continue
                if '=' in line:
                    k, v = line.split('=')
                    parameters[k.strip()] = v.strip()
                    continue
                l = line.strip()
                if not os.path.isfile(l):
                    l = os.path.dirname(file_name) + '/' + line.strip()
                    if os.path.isfile(l):
                        files_list.append(l)
                        continue
                    l = os.getcwd() + '/' + line.strip()
                    if os.path.isfile(l):
                        files_list.append(l)
                        continue
                else:
                    files_list.append(l)
                    continue
            if not section_start and region_name:
                if line[0] == '[':
                    if line.strip('[ ]\n') == region_name:
                        section_start = True
                        enable_comments = True
                        continue
                    else:
                        enable_comments = False
                        continue
    if files_list and parameters:
        return files_list, parameters
    elif files_list:
        return files_list, None
    else:
        return None, None


# TODO: write the logics for the batch mode
def main(*args, **kwargs):
    """Defines the behavior of the app if run in batch mode
    """
    # To load a bunch of regions from files listed in a text file
    if "-batch" in args and "-gui" in args and "filename" in kwargs and "filetype" in kwargs:
        file_name = kwargs["filename"]
        if not os.path.isfile(file_name):
            file_name = os.getcwd() + '/' + file_name
            if not os.path.isfile(file_name):
                print("Can't find the source text file. Specqp process is terminated.")
                sys.exit()
        region_name = None
        if "regionname" in kwargs:
            region_name = kwargs["regionname"]
        fl, pars = parse_file(file_name, region_name)
        if fl and pars:
            call_gui("-batch", "-load", filelist=fl, filetype=kwargs["filetype"], **pars)
        elif fl:
            call_gui("-batch", "-load", filelist=fl, filetype=kwargs["filetype"])
        else:
            print("No data files read from the source text file. Specqp process is terminated.")
            sys.exit()
    # if args is not None:
    #     for i, arg in enumerate(args):
    #         print(f"arg{i}: {arg} of type {type(arg)}")
    # if kwargs is not None:
    #     for key, value in kwargs.items():
    #         print(f"{key}={value}")


if __name__ == "__main__":
    initialize_logging()
    # Setting up service variables, folders, log files path, etc.
    service.prepare_startup()
    specqp_logger.info(f"App started as: {sys.argv}")
    # Enable the case below to force the user to provide arguments
    # if len(sys.argv) < 2:
    #     raise SyntaxError("Insufficient arguments.")

    if len(sys.argv) == 1:
        # If only script name is specified call GUI for interactive work
        specqp_logger.info("Running the app in GUI mode")
        call_gui()
    if len(sys.argv) > 1:
        # If there are additional arguments run in batch mode
        specqp_logger.info("Running the app in BATCH mode")
        args = []
        kwargs = {}
        for arg in sys.argv[1:]:
            if "=" in arg:
                key, val = arg.split('=')
                # If keyword arguments are provided
                kwargs[key.strip()] = val.strip()
            else:
                args.append(arg)
        main(*args, **kwargs)
