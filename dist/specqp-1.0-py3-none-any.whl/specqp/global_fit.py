# The author of this file (global_fit.py) is Patrick Loemker
# e-mail: patrick.loemker@desy.de

import os
import sys
import logging
#import h5py
import numpy as np
from numpy import arctan, cos, pi
from lmfit import Parameters, report_fit, minimize
from matplotlib import pyplot as plt
from matplotlib.widgets import Slider
from scipy.special import wofz
from scipy.integrate import cumtrapz, trapz

from specqp import service
from specqp import launcher

specqp_logger = logging.getLogger("specqp")


def doniach(x, amplitude=1.0, center=0, sigma=1.0, gamma=0.0):
    """Return a Doniach Sunjic asymmetric lineshape, used for photo-emission.

    donaich(x, amplitude, center, sigma, gamma) =
        amplitude / sigma^(1-gamma) *
        cos(pi*gamma/2 + (1-gamma) arctan((x-center)/sigma) /
        (sigma**2 + (x-center)**2)**[(1-gamma)/2]

    see http://www.casaxps.com/help_manual/line_shapes.htm
    stolen...
    """
    arg = (x - center) / sigma
    gm1 = (1.0 - gamma)
    scale = amplitude / (sigma ** gm1)
    return scale * cos(pi * gamma / 2 + gm1 * arctan(arg)) / (1 + arg ** 2) ** (gm1 / 2)


def shirley(y, x=None):
    # calculates shirley background for spectrum
    if x is None:
        x = np.arange(len(y))
    max_iter = 50
    max_rdiff = 1e-5
    x = np.array(x, np.int32)
    y = np.array(y, np.int32)
    step = np.abs(x[1] - x[0])  # equidistant spacing in Ekin
    ## change arrays order to have increasing BE, necessary for Shirley
    if x[0] < x[-1]:
        is_reversed = True
        x = x[::-1]
        y = y[::-1]
    else:
        is_reversed = False
    # Locate the biggest peak.
    maxidx = abs(y - np.amax(y)).argmin()

    # Locate the minima either side of maxidx.
    lmidx = abs(y[0:maxidx] - np.amin(y[0:maxidx])).argmin()
    rmidx = abs(y[maxidx:] - np.amin(y[maxidx:])).argmin() + maxidx
    y_max = y[lmidx]
    y_min = y[rmidx]

    bg = y_min * np.ones_like(y)
    last_full_area = trapz(bg, -x)
    rel_diff = 1
    for it in range(max_iter):
        Y = y - bg
        cumul_area = cumtrapz(Y, -x, initial=0.)
        rel_diff = abs(cumul_area[-1] - last_full_area) / last_full_area
        if rel_diff < max_rdiff:
            break
        last_full_area = cumul_area[-1]
        bg = y_max + (y_max - y_min) * -cumul_area / cumul_area[-1]

    if is_reversed:
        return bg[::-1]
    else:
        return bg


def spec_id(group, id):
    keys = group.keys()
    for key in keys:
        if id in key:
            return group[key]


def V(x, sigma, gamma):
    # voigt function
    sigma = sigma / np.sqrt(2 * np.log(2))
    return np.real(wofz((x + 1j * gamma) / sigma / np.sqrt(2))) / sigma \
           / np.sqrt(2 * np.pi)


# def reduce_spec(spec, axis, a_min, a_max):
#     i_min = np.max(np.argwhere(np.array(axis) > a_min))
#     i_max = np.min(np.argwhere(np.array(axis) < a_max))
#     if i_max < i_min:
#         store = i_max
#         i_max = i_minFull
#         i_min = store
#     reduced_spec = spec[i_min:i_max]
#     reduced_axis = axis[i_min:i_max]
#     return reduced_spec, reduced_axis


class FitGlobal:
    def __init__(self, x, specs):
        """
        :param specs [ndata x npoints] array of spectra
        :param x [npoints] array of x values for data
        """
        self.specs = specs
        self.x = x
        self.ndata = self.specs.shape[0]
        self.npoints = self.specs.shape[1]
        self.no_voigts = None
        self.no_doniachs = None
        self.params = None
        self.result = None

    def plot_trends(self, x=None):
        """Collects params and plots them as a function of x dimension (whatever changes during the fit..)
        """
        vamp, vampe, damp, dampe = self.scrape_param()
        fig, ax = plt.subplots(1, 1)
        if x is None:
            x = np.arange(0, self.ndata, 1)
        for i in range(self.no_voigts):
            ax.errorbar(x, vamp[:, i], yerr=vampe[:, i], label='V%i' % i)
        for i in range(self.no_doniachs):
            ax.errorbar(x, damp[:, i], yerr=dampe[:, i], label='DS%i' % i)
        ax.legend()

    def select_spec(self, selection):
        """Can be used to only select a portion of a spectrum "1,3-4" will remove
        all spectra except those 1,3,4 (of course starting at 0)
        """
        selections = selection.split(',')
        if selections == ['']:
            pass
        else:
            selected_spec = None
            for sel in selections:
                if "-" in sel:
                    strings = sel.split("-")
                    first = int(strings[0])
                    last = int(strings[1]) + 1
                    if selected_spec is None:
                        selected_spec = self.specs[first:last, :]
                    else:
                        selected_spec = np.concatenate((selected_spec, self.specs[first:last, :]), axis=0)
                else:
                    idx = int(sel)
                    if selected_spec is None:
                        selected_spec = self.specs[idx:idx + 1, :]
                    else:
                        selected_spec = np.concatenate((selected_spec, self.specs[idx:idx + 1, :]), axis=0)
            self.specs = selected_spec
            self.ndata = selected_spec.shape[0]

    def scrape_param(self):
        """Collects all amplitudes and errors of voigts and doniachs
        """
        assert isinstance(self.params, Parameters)
        keys = self.params.keys()
        vamp = np.zeros((self.ndata, self.no_voigts))
        vampe = np.zeros((self.ndata, self.no_voigts))
        damp = np.zeros((self.ndata, self.no_doniachs))
        dampe = np.zeros((self.ndata, self.no_doniachs))
        for elem in keys:
            if 'vamp' in elem:
                for i in range(self.no_voigts):
                    for j in range(self.ndata):
                        vamp[j, i] = self.params['vamp_{}_{}'.format(i, j)].value
                        vampe[j, i] = self.params['vamp_{}_{}'.format(i, j)].stderr
            elif 'damp' in elem:
                for i in range(self.no_doniachs):
                    for j in range(self.ndata):
                        damp[j, i] = self.params['damp_{}_{}'.format(i, j)].value
                        dampe[j, i] = self.params['damp_{}_{}'.format(i, j)].stderr
        return vamp, vampe, damp, dampe

    def plot_residual_interactive(self):
        """Plots a window of fit, its components and residual
        contains slider that allows to slide trough spectra
        """
        residual = np.resize(self.result.residual, new_shape=self.specs.shape)
        fig, ax = plt.subplots(2, 1, sharex='col')
        plt.subplots_adjust(bottom=0.2)
        # plt.ylim(self.specs.min(), self.specs.max())
        axidx = plt.axes([0.25, 0.1, 0.65, 0.03])
        # if the returned sidx (slider object) is destroyed the slider
        # loses its functionality!
        self.sidx = Slider(axidx, 'Spec#', 0, self.ndata - 1, valinit=0, valstep=1)

        def update(idx):
            idx = int(idx)
            ax[0].cla()
            ax[1].cla()
            self.plot_components(idx, self.x, self.result.params, ax[0])
            ax[0].plot(self.x, self.specs[idx, :], '.', label='S')
            ax[0].plot(self.x, self.model(self.x, self.result.params, idx), label='M')
            ax[0].legend()
            ax[1].plot(self.x, residual[idx, :])
            high = np.max(self.x)
            low = np.min(self.x)
            plt.sca(ax[0])
            plt.xlim(high, low)
            # plt.ylim(self.specs.min(), self.specs.max())

        self.sidx.on_changed(update)
        update(0)

    def model(self, x, params, i):
        """Defines the model for the fit (doniachs, voigts, shirley bg, linear bg
        """
        line = params['m_%i' % i] * (x - x.min()) + params['b_%i' % i]
        voigts = np.zeros_like(x)
        ds = np.zeros_like(x)
        for j in range(self.no_voigts):
            voigts += params['vamp_{}_{}'.format(j, i)] * V(x - params['vcen_{}_{}'.format(j, i)],
                                                            params['vsig_{}_{}'.format(j, i)],
                                                            params['vgam_{}_{}'.format(j, i)])
        for j in range(self.no_doniachs):
            ds += doniach(x, params['damp_{}_{}'.format(j, i)], params['dcen_{}_{}'.format(j, i)],
                          params['dsig_{}_{}'.format(j, i)], params['dgam_{}_{}'.format(j, i)])
        return line + self.bg[i, :] + voigts + ds

    def objective(self, params, x, data):
        """Calculates total residual for fits to several data sets held
        in a 2-D array, and modeled by model function
        """
        resid = 0.0 * data[:]
        # make residual per data set
        for i in range(self.ndata):
            resid[i, :] = data[i, :] - self.model(x, params, i)
        return resid.flatten()

    def plot_components(self, i, x, params, ax):
        """Plots the component i onto ax using params
        """
        line = params['m_%i' % i] * (x - x.min()) + params['b_%i' % i]
        for j in range(self.no_voigts):
            voigt = line + self.bg[i, :] + params['vamp_{}_{}'.format(j, i)] * V(x - params['vcen_{}_{}'.format(j, i)],
                                                                                 params['vsig_{}_{}'.format(j, i)],
                                                                                 params['vgam_{}_{}'.format(j, i)])
            ax.plot(x, voigt, label='V%i' % j)
        for j in range(self.no_doniachs):
            ds = line + self.bg[i, :] + doniach(x, params['damp_{}_{}'.format(j, i)], params['dcen_{}_{}'.format(j, i)],
                                                params['dsig_{}_{}'.format(j, i)], params['dgam_{}_{}'.format(j, i)])
            ax.plot(x, ds, label='DS%i' % i)
        ax.plot(x, self.bg[i, :] + line, label='BG')

    def make_params(self, bgparams, vparams, dparams, c_win):
        """Uses the starting values for the first peak to construct
        free variable voigts and doniachs for peak 0
        and dependent centers, sigmas and gammas for all other peaks
        amplitude is only free parameter
        """
        params = Parameters()
        if vparams:
            self.no_voigts = len(vparams[1])
        else:
            self.no_voigts = 0
        if dparams:
            self.no_doniachs = len(dparams[1])
        else:
            self.no_doniachs = 0
        bg = np.zeros((self.ndata, self.npoints))
        for i in range(self.ndata):
            params.add('m_{}'.format(i), value=bgparams[i][0])
            params.add('b_{}'.format(i), value=bgparams[i][1])
            bg[i, :] = shirley(self.specs[i, :], self.x)
            for j in range(self.no_voigts):
                params.add('vamp_{}_{}'.format(j, i), value=vparams[0][i][j], min=0)
                params.add('vcen_{}_{}'.format(j, i), value=vparams[1][j], min=vparams[1][j] - c_win,
                           max=vparams[1][j] + c_win)
                params.add('vsig_{}_{}'.format(j, i), vary=True, value=vparams[2][j], min=vparams[2][j] - vparams[4][j],
                           max=vparams[2][j] + vparams[4][j])
                params.add('vgam_{}_{}'.format(j, i), vary=True, value=vparams[3][j], min=vparams[3][j] - vparams[5][j],
                           max=vparams[3][j] + vparams[5][j])
            for j in range(self.no_doniachs):
                params.add('damp_{}_{}'.format(j, i), value=dparams[0][i][j], min=0)
                params.add('dcen_{}_{}'.format(j, i), value=dparams[1][j], min=dparams[1][j] - c_win,
                           max=dparams[1][j] + c_win)
                params.add('dsig_{}_{}'.format(j, i), vary=True, value=dparams[2][j], min=dparams[2][j] - dparams[4][j],
                           max=dparams[2][j] + dparams[4][j])
                params.add('dgam_{}_{}'.format(j, i), vary=True, value=dparams[3][j], min=dparams[3][j] - dparams[5][j],
                           max=dparams[3][j] + dparams[5][j])

        for i in range(1, self.ndata):
            for j in range(self.no_voigts):
                params['vcen_{}_{}'.format(j, i)].expr = 'vcen_{}_0'.format(j)
                params['vsig_{}_{}'.format(j, i)].expr = 'vsig_{}_0'.format(j)
                params['vgam_{}_{}'.format(j, i)].expr = 'vgam_{}_0'.format(j)
            for j in range(self.no_doniachs):
                params['dcen_{}_{}'.format(j, i)].expr = 'dcen_{}_0'.format(j)
                params['dsig_{}_{}'.format(j, i)].expr = 'dsig_{}_0'.format(j)
                params['dgam_{}_{}'.format(j, i)].expr = 'dgam_{}_0'.format(j)
        self.bg = bg
        self.params = params

    def fit(self):
        """Calls minimize from lmfit using the objective function and the parameters
        """
        self.result = minimize(self.objective, self.params, args=(self.x, self.specs), method='least_squares')
        self.params = self.result.params
        report_fit(self.result, sort_pars=True, show_correl=False)
        return self.result

    def save_fits(self, key):
        """Stores pickled object for future reference in subfolder "fits" relative to cwd
        """
        with open('./fits/{}.fit'.format(key), 'w+') as f:
            f.write(self.result.params.dumps())


# # TODO: Write hdf5 files reading routine
# def read_hdf5(filename):
#     f = h5py.File(filename)
#     raw = f["rawdata"]
#     co2_ids = ['0478', '0482', '0486', '0491', '0495', '0499']
#     T = np.linspace(50, 300, 6)
#     specs = []
#     for id in co2_ids:
#         specs += [spec_id(raw, id)]



def do_global_fit(regions, )
    T = np.linspace(50, 300, 6)


def main(*args, **kwargs):
    label = 'C1s'

    c1ses = np.empty((6, 181))
    gases = np.empty((6, 121))

    upper = 296
    middle = 290
    lower = 281

    for i, spec in enumerate(specs):
        gas, gasx = reduce_spec(spec['sum'].value, spec['x_b'].value, upper, middle)
        c1s, c1sx = reduce_spec(spec['sum'].value, spec['x_b'].value, middle, lower)
        c1ses[i, :] = c1s
        gases[i, :] = gas

    x = c1sx
    x_g = gasx

    fit = FitGlobal(x, c1ses)
    # fit.select_spec('0,1,6,13')
    ndata = fit.ndata
    c_win = 0.5

    vc = [283.5, 284.5, 285.5]  # , 534, 534.6, 536.2]
    sigma = [0.3, 0.3, 0.3]  # , 0.3, 0.3, 0.3]
    gamma = [0.4, 0.4, 0.4]  # , 0.4, 0.4, 0.4]

    dsigma = [0.7]
    dgamma = [-.2]
    dc = [529.7]
    bgparams = [[0., 0]] * ndata
    vamps = [[3000, 1000, 1500]] * ndata
    wsigma = [0.2] * len(vc)
    wgamma = wsigma
    damps = [[3000]] * ndata
    dwsigma = wsigma
    dwgamma = wsigma

    vparams = [vamps, vc, sigma, gamma, wsigma, wgamma]
    dparams = []  # [damps, dc, dsigma, dgamma, dwsigma, dwgamma]
    fit.make_params(bgparams, vparams, None, c_win)
    result = fit.fit()
    fit.save_fits(label)
    fit.plot_trends(T)
    fit.plot_residual_interactive()

    plt.show()


# TODO: write the routine for batch file processing
if __name__ == "__main__":
    launcher.initialize_logging()
    # Setting up service variables, folders, log files path, etc.
    service.prepare_startup()
    specqp_logger.info(f"specqp.global_fit module started as : {sys.argv}")
    # Enable the case below to force the user to provide arguments
    # if len(sys.argv) < 2:
    #     raise SyntaxError("Insufficient arguments.")

    if len(sys.argv) == 1:
        # If only script name is specified call GUI for interactive work
        specqp_logger.info("To run the general GUI mode, call the specqp.launcher module. Terminated.")

    if len(sys.argv) > 1:
        # If there are additional arguments run in batch mode
        specqp_logger.info("Running the specqp.global_fit module in the background mode.")
        args = []
        kwargs = {}
        for arg in sys.argv[1:]:
            if "=" in arg:
                key, val = arg.split('=')
                # If keyword arguments are provided
                kwargs[key.strip()] = val.strip()
            else:
                args.append(arg)
        main(*args, **kwargs)
